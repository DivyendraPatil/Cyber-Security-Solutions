package cpuscheduling;

public class Sim {
	public static void main(String[] args) {
		Sim5_3.main(null);
		Sim5_12.main(null);
		Sim2.main(null);
	}
}